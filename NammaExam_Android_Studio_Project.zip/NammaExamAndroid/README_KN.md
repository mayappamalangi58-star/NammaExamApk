# Namma Exam Android App (WebView wrapper)

ಈ project ನಿಮ್ಮ `NammaExam.html` ಅನ್ನು Android WebView ಒಳಗೆ ತೆರೆಯುತ್ತದೆ.
ಮೂಲ HTML quiz/video creator ಕಾರ್ಯಗಳನ್ನು ಉಳಿಸಲಾಗಿದೆ; `recorder.start();8`
ಎಂಬ JavaScript syntax error ಅನ್ನು `recorder.start();` ಎಂದು ಸರಿಪಡಿಸಲಾಗಿದೆ.

## APK ನಿರ್ಮಿಸುವುದು
1. Android Studio (Ladybug ಅಥವಾ ಹೊಸದು) install ಮಾಡಿ.
2. ಈ folder ಅನ್ನು Android Studio ನಲ್ಲಿ Open ಮಾಡಿ.
3. Android SDK Platform 35 install ಮಾಡಲು ಕೇಳಿದರೆ install ಮಾಡಿ.
4. Gradle Sync ಪೂರ್ಣಗೊಳ್ಳಲಿ.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ಆಯ್ಕೆಮಾಡಿ.
6. Debug APK ಸಾಮಾನ್ಯವಾಗಿ `app/build/outputs/apk/debug/app-debug.apk` ನಲ್ಲಿ ಸಿಗುತ್ತದೆ.

## ಮುಖ್ಯ ಸೂಚನೆಗಳು
- Video generation ಗೆ Internet ಮತ್ತು ಮಾನ್ಯ Sarvam AI API key ಅಗತ್ಯ.
- Sarvam API key ಅನ್ನು ಯಾರೊಂದಿಗೂ ಹಂಚಿಕೊಳ್ಳಬೇಡಿ. ಈಗಿನ HTML key ಅನ್ನು input field ನಲ್ಲಿ
  runtime ಸಮಯದಲ್ಲಿ ಬಳಸುತ್ತದೆ; ಈ starter project ಅದನ್ನು hard-code ಮಾಡುವುದಿಲ್ಲ.
- Android WebView ಮತ್ತು Sarvam API ನಡುವೆ CORS/API ಅನುಮತಿ ಸಮಸ್ಯೆ ಬಂದರೆ,
  API request ಅನ್ನು ಸುರಕ್ಷಿತ backend ಮೂಲಕ proxy ಮಾಡಬೇಕಾಗಬಹುದು.
- ಈ ಪರಿಸರದಲ್ಲಿ Android SDK/Gradle build toolchain ಇಲ್ಲದ ಕಾರಣ ಇಲ್ಲಿ ನೇರವಾಗಿ
  compiled APK ಸೃಷ್ಟಿಸಲಾಗಿಲ್ಲ. ಈ project Android Studio ಯಲ್ಲಿ build ಮಾಡಲು ಸಿದ್ಧಪಡಿಸಲಾಗಿದೆ.
